import mongoose from "mongoose";
const coneccionDB = async ()=>{
    try {
        const connection= await mongoose.connect(process.env.CONEXION,
            {
                useNewUrlParser:true,
                useUnifiedTopology:true
            });
            const url = `${(connection).connection.host}: ${(connection).connection.port}`
            console.log(url)
    } catch (error) {
        console.log(error);
        process.exit(1);
    }
}
export default coneccionDB;